# insan_algi > 2023-10-26 1:32am
https://universe.roboflow.com/ayenur/insan_algi-v11g8

Provided by a Roboflow user
License: CC BY 4.0

